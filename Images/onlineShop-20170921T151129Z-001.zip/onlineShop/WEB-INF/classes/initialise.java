import itemBean.item;
import itemDao.itemDao;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class initialise extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		Cookie user = new Cookie("User",request.getParameter("val"));
		response.addCookie(user);
	}
}