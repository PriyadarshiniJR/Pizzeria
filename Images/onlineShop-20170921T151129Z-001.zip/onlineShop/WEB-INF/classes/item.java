package itemBean;

public class item{
	int id, price,vnv;
	String name, content,category;

	public void setId(int value){
		id = value;
	}

	public void setCategory(String value){
		category = value;
	}

	public void setPrice(int value){
		price = value;
	}

	public void setName(String value){
		name = value;
	}

	public void setContent(String value){
		content = value;
	}

	public void setVnv(int value){
		vnv = value;
	}

	public int getId(){
		return id;
	}

	public String getCategory(){
		return category;
	}

	public int getPrice(){
		return price;
	}

	public String getName(){
		return name;
	}

	public String getContent(){
		return content;
	}

	public int getVnv(int value){
		return vnv;
	} 
}