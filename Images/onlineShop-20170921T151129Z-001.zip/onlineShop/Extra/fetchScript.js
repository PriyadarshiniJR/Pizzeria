var url;
function fetch(category)
{
	url = "fetch?val="+category;
	var obj = new XMLHttpRequest();
	obj.onreadystatechange = function(){
		if(this.readyState==4){
			document.getElementById("itemList").innerHTML="";
			//console.log(this.responseText);
			document.getElementById("itemList").innerHTML += this.responseText;
		}
	}
	obj.open("GET",url,true);
	obj.send();
}

function init()
{
	url = "initialise?val=Guest";
	var obj = new XMLHttpRequest();
	obj.onreadystatechange = function(){
		if(this.readyState==4){
			fetch('Appetisers');
			displayCart();
		}
	}
	obj.open("GET",url,true);
	obj.send();
}


function cart(id,number)
{
	var count = parseInt(document.getElementsByName('text')[number].value);
	url = "cookie?id="+id+"&count="+count;
	var obj = new XMLHttpRequest();
	obj.onreadystatechange = function(){
		if(this.readyState==4){
			//document.getElementById("itemList").innerHTML = this.responseText;
			//console.log(this.responseText);
			displayCart();
		}
	}
	obj.open("GET",url,true);
	obj.send();
}

function updateCart(id,temp)
{
	/*console.log(number);
	var count = parseInt(document.getElementsByClassName('quantity')[number].value);
	url = "cookie?id="+id+"&count="+count+"&replace="+replace;
	var obj = new XMLHttpRequest();
	obj.onreadystatechange = function(){
		if(this.readyState==4){
			//document.getElementById("itemList").innerHTML = this.responseText;
			//console.log(this.responseText);
			displayCart();
		}
	}
	obj.open("GET",url,true);
	obj.send();*/
	document.cookie = id + "="+temp.previousElementSibling.value+";";
	console.log(temp.previousElementSibling.value);
	displayCart();
}

function displayCart()
{
	url = "cart";
	var obj = new XMLHttpRequest();
	obj.onreadystatechange = function(){
		if(this.readyState==4){
			document.getElementById("cart").innerHTML ="";
			//console.log("Line 54" + this.responseText);
			document.getElementById("cart").innerHTML += this.responseText;

			computeTotal();
		}
	}
	obj.open("GET",url,true);
	obj.send();
}

function computeTotal(){
	var ct=0;
	var list = document.getElementsByClassName('subtotal');
	for(var i=0;i<list.length;i++)
		ct+=parseInt(list[i].innerHTML);

	var tax = (0.18 * ct).toFixed(2);
	ct=ct+parseInt(tax);
	document.getElementById("total").innerHTML = ct+"";
	document.getElementById("taxes").innerHTML = tax+"";
	//console.log(ct);
}

function plusBtn(number){
	var content = document.getElementsByName('text')[number];
	//console.log(content.value);
	var count = parseInt(content.value);
	content.value = count+1;
}

function minusBtn(number){
	var content = document.getElementsByName('text')[number];
	//console.log(content.value);
	var count = parseInt(content.value);
	if(count!=1)
		content.value = count-1;
	else if(count==1)
	{
		window.alert("Quantity cannot be 0. Click X to remove.");
	}
}

function deleteCookie(id){
	document.cookie = id + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
	displayCart();
}
